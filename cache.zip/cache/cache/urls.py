
from django.contrib import admin
from django.urls import path
from app import views
from django.views.decorators.cache import cache_page


urlpatterns = [
    path('admin/', admin.site.urls),
    # path('', views.home),
    path("",cache_page(60)(views.home),name="home") ,#cache with the url
    path('contact/', views.contact),
    

]
