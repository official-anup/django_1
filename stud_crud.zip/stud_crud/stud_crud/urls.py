
from django.contrib import admin
from django.urls import path
from app import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.addshow,name="addshow"),
    path('delete/<int:id>/', views.delete_view,name="delete"),
    path('<int:id>/', views.update_view,name="update"),
    
    
    
]
