from django import forms
from .models import Student_model 

class Student_form(forms.ModelForm):
    class Meta:
        model=Student_model
        fields=["name","email","password","std"]
        widgets={
            "name":forms.TextInput(attrs={"class":"form-control"}),
            
            "email":forms.EmailInput(attrs={"class":"form-control"}),
            
            "password":forms.PasswordInput(attrs={"class":"form-control"},render_value=True),
            # render value is to show password value in the form in update form.
            
            
            "std":forms.NumberInput(attrs={"class":"form-control"}),
        }