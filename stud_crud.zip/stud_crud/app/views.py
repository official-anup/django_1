# from django.http import HttpResponseRedirect
from django.shortcuts import render,HttpResponseRedirect
from .forms import Student_form
from .models import Student_model
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.

@APIView("GET")
def addshow(request):
            if request.method=="POST":
                fm=Student_form(request.POST)
                if fm.is_valid():
                    # fm.save()
                    name=request.POST["name"]
                    email=request.POST["email"]
                    password=request.POST["password"]
                    std=request.POST["std"]
                    
                    add=Student_model(name=name,email=email,password=password,std=std)
                    fm=Student_form() # This is to show blank form after submit
                
                    add.save()
    
            else:
                fm=Student_form()
            stud=Student_model.objects.all()
                
            return render(request,"app/addshow.html",{"form":fm,"stud":stud})
        


def delete_view(request,id):
    if request.method=="POST":
        obj=Student_model.objects.get(pk=id)
        obj.delete()
        # obj.update()
        return HttpResponseRedirect("/")
    
def update_view(request,id):
   if request.method=="POST":
       pi=Student_model.objects.get(pk=id)
       fm=Student_form(request.POST,instance=pi)
       
       if fm.is_valid():
           fm.save()
       
   else:
    pi=Student_model.objects.get(pk=id)
    fm=Student_form(instance=pi)
    
   return render(request,"app/update.html",{"form":fm})