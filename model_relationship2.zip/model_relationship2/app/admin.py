from django.contrib import admin
from .models import User,Page,Like
# Register your models here.


@admin.register(Page)
class PageAdmin(admin.ModelAdmin):
    list_display=["user","page_name","page_category","page_publish"]
    
@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display=["user","page_name","page_category","page_publish","likes"]