from django.db import models
from django.contrib.auth.models import User
# Create your models here.

#after doing any changes wee have to makemigratre and 
#migrate.
"""
class Page(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    
    # user=models.OneToOneField(User,on_delete=models.PROTECT,primary_key=True) #if we write protect then user will not delete until the page delete.
    
    # user=models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True,limit_choices_to={"is_staff":True}) #jo v staff=true hoga wo bs pages create kr payega.
    
    
    page_name=models.CharField(max_length=70)
    page_category=models.CharField(max_length=80)
    page_publish=models.DateField()
"""


############### for the parent_link=True ###############################
"""
-for this we will not use signals so that we will comment requirements for the signals from apps.py and __init__.py.

-Like class will inherites all the feilds of the Page class and when we delete class it it also delete like realted to it.

-And if we delete like then it will delete the page realetd to it,but not the user bcz we are  not using signals here.
"""

class Page(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)    
    page_name=models.CharField(max_length=70)
    page_category=models.CharField(max_length=80)
    page_publish=models.DateField()
    
    
class Like(Page):
    panna=models.OneToOneField(Page,on_delete=models.CASCADE,primary_key=True,parent_link=True)    
    likes=models.IntegerField()