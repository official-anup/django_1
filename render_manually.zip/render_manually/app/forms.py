from django.forms import forms 
from django import forms

class LoginForm(forms.Form):
    name=forms.CharField(initial="Anup",help_text="This field will contain only 30 letters")
    
    email=forms.EmailField()