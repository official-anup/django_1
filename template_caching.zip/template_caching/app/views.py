from django.shortcuts import render
from django.views.decorators.cache import cache_page

# Create your views here.

#86
"""
def home(request):
    # see setting file at the last
    return render(request,"index.html")
    
""" 

# 87 
# @cache_page(20)
def home(request):
    return render(request,"index.html")

def contact(request):
    return render(request,"contact.html")