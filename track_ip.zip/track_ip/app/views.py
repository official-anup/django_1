from django.shortcuts import render,HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm,UserChangeForm
from .forms import SignUpForm,EditUserprofile,EditAdminprofile
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm,PasswordChangeForm,SetPasswordForm
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

# Create your views here.

# This is to use default forms with default fields
def Regi(request):
    if request.method=="POST":
       fm=UserCreationForm(request.POST)
       if fm.is_valid():
           messages.success(request,"Account created successfully.")
           fm.save()    
    else:
       fm=UserCreationForm()
    return render(request,"registration.html",{"form":fm})

# This is to use our forms with out specified fields
def signup(request):
    if request.method=="POST":
       fm=SignUpForm(request.POST)
    #    fm.field_order(field_order=["email","username"])
       if fm.is_valid():
           messages.success(request,"Account created successfully.")
           fm.save()
      #  return HttpResponseRedirect("/login/")
           
    
    else:
       fm=SignUpForm()
    return render(request,"registration.html",{"form":fm})
 
def loginform(request):
 if not request.user.is_authenticated:
    if request.method=="POST":
      fm=AuthenticationForm(request=request,data=request.POST)
      if fm.is_valid():
         uname=fm.cleaned_data["username"]
         upass=fm.cleaned_data["password"]
         user=authenticate(username=uname,password=upass)
         if user is not None:
            login(request,user)
            messages.success(request,"Logged in successfully !!")
            return HttpResponseRedirect("/profile/")
    else:
      fm=AuthenticationForm()
   
    return render(request,"login.html",{"form":fm})
 else:
      return HttpResponseRedirect("/profile/")  
   
# @ login_required
def profile(request):
   if request.user.is_authenticated:
      if request.method=="POST":
         if request.user.is_superuser==True:
            fm=EditAdminprofile(request.POST,instance=request.user)
            user=User.objects.all()
            # ip=request.session.get("ip",0) 
         else:  
           fm=EditUserprofile(request.POST,instance=request.user)
           user=None
         if fm.is_valid():
            messages.success(request,"Profile updates successfully !")
            fm.save()
      
      else:
         if request.user.is_superuser==True:
            fm=EditAdminprofile(instance=request.user)
            user=User.objects.all()
         else:  
            fm=EditUserprofile(instance=request.user)
            user=None
            
      return render(request,"profile.html",{"name":request.user,"form":fm,"user":user})
   else:
      return HttpResponseRedirect("/profile/")

# @ login_required
def logoutview(request):
    logout(request)
    return HttpResponseRedirect("/")
 
 
 # change pass with old password
def change_pass(request):
   if request.user.is_authenticated:
      if request.method=="POST":
         fm=PasswordChangeForm(user=request.user,data=request.POST)
         if fm.is_valid():
            fm.save()
            update_session_auth_hash(request,fm.user) #This is because password update k bad ye logout krke login pe jara than but hme profile pe bhejna tha
            messages.success(request,"Password changed successfully.")
            return HttpResponseRedirect("/profile/")
      else:
         fm=PasswordChangeForm(user=request.user)
      return render(request,"change_pass.html",{"form":fm})
   
   else:
            return HttpResponseRedirect("/")
      
# change pass without old password
def change_pass1(request):
   if request.user.is_authenticated:
      if request.method=="POST":
         fm=SetPasswordForm(user=request.user,data=request.POST)
         if fm.is_valid():
            fm.save()
            update_session_auth_hash(request,fm.user) #This is because password update k bad ye logout krke login pe jara than but hme profile pe bhejna tha
            messages.success(request,"Password changed successfully.")
            return HttpResponseRedirect("/profile/")
      else:
         fm=SetPasswordForm(user=request.user)
      return render(request,"change_pass1.html",{"form":fm})
   
   else:
            return HttpResponseRedirect("/")
      
      

def userdetails(request,id):
   if request.user.is_authenticated:
      pi=User.objects.get(pk=id) 
      fm=EditAdminprofile(instance=pi)
      return render(request,"userdetails.html",{"form":fm})