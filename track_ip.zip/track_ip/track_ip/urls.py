
from django.contrib import admin
from django.urls import path
from app import views
# from app.forms import LoginForm
from django.contrib.auth.views import LoginView
from django.contrib.auth import views as auth_view 

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('signup1/', views.Regi),
    path('signup2/', views.signup,name="signup"),
    path('', views.loginform,name="login"),
    # path('', auth_view.LoginView.as_view(template_name="login.html",authentication_form=LoginForm),name="login"),
    
    
    path('profile/', views.profile,name="profile"),
    path('logout/', views.logoutview,name="logout"),
    path('change_pass/', views.change_pass,name="change_pass"),
    path('change_pass1/', views.change_pass1,name="change_pass1"),
    path('userdetails/<int:id>/', views.userdetails,name="userdetails"),
    
    
    
    
    
    
    
    
    
]
