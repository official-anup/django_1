from django.shortcuts import render
from app.models import Student
# Create your views here.
def home(request):
    stu=Student.objects.all()
    
    # stu=Student.objects.get(pk=2)   #if we use get then remove for loop in template file 
    
    
    return render(request,"app/index.html",{"stu":stu})