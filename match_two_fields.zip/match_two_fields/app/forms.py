from typing import Any, Dict
from django.forms import forms 
from django import forms
from django.core import validators 


# field errors 

class Student(forms.Form):
    error_css_class = "errorlist"
    required_css_class ="required"
    
    name=forms.CharField(error_messages={"required":"Enter your name !"})
    
    email=forms.EmailField(error_messages={"required":"Enter your email !"},min_length=5,max_length=50)
    
    password=forms.CharField(widget=forms.PasswordInput,error_messages={"required":"Enter your password !"},min_length=5,max_length=50)
    

    
#####################################################

# Match two fields 
"""
class Student(forms.Form):
    name=forms.CharField()

    password=forms.CharField(widget=forms.PasswordInput)
    rpassword=forms.CharField(widget=forms.PasswordInput,label="Password(again)")

    def clean(self):
        clean_data=super().clean()
        
        pwd=clean_data["password"]
        rpwd=clean_data["rpassword"]
        
        if pwd!=rpwd:
            raise forms.ValidationError("Password not matched !")
        
        else:
            raise forms.ValidationError("Password  matched !")
        
        
"""

#######################################################
# Built in validators
"""
class Student(forms.Form):
    name=forms.CharField(validators=[validators.MaxLengthValidator(15)])
    
    emial=forms.EmailField()
    
"""

# custom validators 
"""
def starts_with_s(input):
    if input[0]!="s".casefold():
        raise forms.ValidationError("Name should starts with S.")

class Student(forms.Form):
    name=forms.CharField(validators=[starts_with_s])
    email=forms.EmailField()
"""
####################################################

# validation for one field
#############################################
"""
class Student(forms.Form):
    name=forms.CharField()
    
    def clean_name(self):
                valname=self.cleaned_data["name"]
                if len(valname)<4:
                    raise forms.ValidationError("Enter more than 4 charecter")
                return valname

"""
# validation for the whole form
#############################################
"""

class Student(forms.Form):
    name=forms.CharField()
    email=forms.EmailField()
    
    def clean(self):
        clean_data=super().clean()
        
        valname=self.cleaned_data["name"]
        valemail=self.cleaned_data["email"]
        
        # If both the feilds have errors then only first field error will shown.
        
        if len(valname)<4:
            raise forms.ValidationError("Name should be more or equal to 4 !")
        
        
        if len(valemail)<8:
            raise forms.ValidationError("Email should be more than 8 charectors.")

"""
