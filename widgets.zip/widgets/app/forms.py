from django.forms import forms 
from django import forms

class LoginForm(forms.Form):
    # name=forms.CharField(label_suffix="  ==>  (label_suffix)",initial="Anup (Initial value,but we give this initial value in view.py ie. in runtime then this will display.)",label=" Full Name (label)",required=False,disabled=False,help_text="This is for the Full name (help text)")
    
    name=forms.CharField(widget=forms.PasswordInput)
    name2=forms.CharField(widget=forms.TextInput(attrs={"class":"someclass1","id":"name2","class":"form-control"}))
    
    email=forms.EmailField(widget=forms.HiddenInput)
    text=forms.CharField(widget=forms.Textarea)
    text3=forms.CharField(widget=forms.CheckboxInput)
    text4=forms.CharField(widget=forms.FileInput)
    
    
    
    mobile=forms.IntegerField()
    
    key=forms.CharField(widget=forms.HiddenInput())
    