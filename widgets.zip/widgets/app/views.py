from django.shortcuts import render
from .forms import LoginForm
# Create your views here.

def ShowForm(request):
    # fm=LoginForm(auto_id="some_%s",label_suffix=" ",initial={"name":"Anup Alone"})
    # fm.order_fields(field_order=["email","name"])
    # "some_%s" will set id=some_name or some_email according to the field.
     
    # fm=LoginForm(auto_id=True) 
    # if we set true then id=id_name and id=id_email
    
    # fm=LoginForm(auto_id=False) 
    # if we set true then id=name and id=email
    
    # fm=LoginForm(auto_id="anup") 
    # it will remove label and id attribute.
    
    #######################################################
    # Rendering manually
    fm=LoginForm()
    return render(request,"app/index.html",{"form":fm})