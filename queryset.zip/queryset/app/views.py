from django.shortcuts import render
from .models import Student,Teacher
# Create your views here.

# def home(request):
    
    # std=Student.objects.all()
    # std=Student.objects.filter(marks__gt=80)
    # std=Student.objects.filter(city="pune")
    # std=Student.objects.exclude(city="pune")
    
    # #attach "-" before anything and it will sort by descending order
    # std=Student.objects.order_by("-city")
    # std=Student.objects.order_by("pass_date")
    
    
    #random
    # std=Student.objects.order_by("?")
    
    
    #reverse
    # std=Student.objects.order_by("id").reverse()[:5]
    
    ############ values for dict #################
    # values: it returns list of dict
    # std=Student.objects.values()
    # std=Student.objects.values("name","city")
    # std=Student.objects.only("name","city")
    
    
    ############ values_list for tupple #################
    # std=Student.objects.values_list("name","city",named=True)
    
    ############## using(alias) ##########################
    # std=Student.objects.using("default")#this default is from the setting.py where default database is defined.

##################### dates ###############################
    # std=Student.objects.dates("pass_date","month")
    # std=Student.objects.dates("pass_date","year")
     

#################### union ###########################
    # q1=Student.objects.values_list("id","name","roll",named=True)
    # q2=Teacher.objects.values_list("id","name","e_num",named=True)
    # std=q1.union(q2)
    # SELECT "app_student"."id" AS "col1", "app_student"."name" AS "col2", "app_student"."roll" AS "col3" FROM "app_student" UNION SELECT "app_teacher"."id" AS "col1", "app_teacher"."name" AS "col2", "app_teacher"."e_num" AS "col3" FROM "app_teacher"
    
    
    #################### intersection ###########################
    # q1=Student.objects.values_list("id","name","roll",named=True)
    # q2=Teacher.objects.values_list("id","name","e_num",named=True)
    # std=q1.intersection(q2)
    
     #################### difference ###########################
     #it will not fetch  same names from the tables,but fetch all the rest of the names,but not of the secod table.
    # q1=Student.objects.values_list("id","name",named=True)
    # q2=Teacher.objects.values_list("id","name",named=True)
    # std=q2.difference(q1)
    
    ################### or #####################
     # std=Student.objects.filter(Q(name__startswith="a") | Q(name__startswith="a"))
    
    # std=Student.objects.filter(name__startswith="a") | Student.objects.filter(city__startswith="a")
    
    ############## and ########################
    # std=Student.objects.filter(roll=2) & Student.objects.filter(name="Monti")
    
    ##################################################################### METHOD THAT DO NOT RETURNS NEW QUERYSETS  ################################
def home(request):
    # ############## get ########################
    # st=Student.objects.get(pk=1)
    
     ############## first and last ########################
    # st=Student.objects.first()
    # st=Student.objects.last()

 # ############## latest ########################
    # st=Student.objects.latest("name")
    # st=Student.objects.latest("pass_date")

#  ############### latest ########################
#     st=Student.objects.earliest("pass_date")


#  ############### exist for all ########################
    # st=Student.objects.all()
    # print(st.exists()) # returns true if data is exists
    
 ############### exist for one ########################
    # st=Student.objects.all()
    # st1=Student.objects.get(pk=1)
    # print(st.filter(pk=st1.pk).exists()) # returns true if data is exists
    
############### latest ########################
    # st=Student.objects.earliest("pass_date")

################# create #############################
# keep fields empty by doing this marks=""
    # st=Student.objects.create(name="Anjali",roll=10,city="nanded",marks=99,pass_date="2020-5-4")
    
################# get or create #############################
    # st,created=Student.objects.get_or_create(name="Prajali",roll=11,city="chanda",marks=89,pass_date="2020-6-4")
    # print(f"created : {created}")
    
################### update ##########################
    # st=Student.objects.filter(id=1).update(name="Anup",roll=1,city="pune",marks=100,pass_date="2020-5-4")
    
    # st=Student.objects.filter(id=1).update(name="Anup",pass_date="2020-5-4")
    
    # st=Student.objects.filter(id=9).update(city="pune")
    
    # st=Student.objects.filter(marks__gte=90).update(city="pune")
    
    
################### update or create ##########################
    # st,created=Student.objects.update_or_create(id=3,name="Minti",defaults={"name":"MintiAnup"})
    # print(created)
   

################### bulk-create  ##########################
    # objs=[
    #     Student(name="Anuj",roll=12,city="mumbai",marks=91,pass_date="2020-1-4"),
    #     Student(name="Manoj",roll=13,city="savali",marks=92,pass_date="2022-1-4"),
    #     Student(name="Suraj",roll=14,city="ghot",marks=93,pass_date="2023-1-4")
    # ]
    # st=Student.objects.bulk_create(objs)
    
################### bulk-update  ##########################
    # all=Student.objects.all()
   
    # for stu in all:
    #     stu.city="bhel"
    
    # st=Student.objects.bulk_update(all,["city"])
    
################### in-bulk  ##########################
    # st=Student.objects.in_bulk([1,2])
    # print(st[1].name)
    
    # st=Student.objects.in_bulk([]) # this will return empty dict
  
    # st=Student.objects.in_bulk() # This will retun all the values from the table
    # print(st)
  
  
################### delete  ##########################
    # st=Student.objects.get(pk=13).delete()
    # st=Student.objects.filter(marks=70).delete()
    # st=Student.objects.all().delete()

################### count  ##########################
    # st=Student.objects.all().count()
    # st=Student.objects.filter(marks__gte=90).count()

################### explain  ##########################
    # st=Student.objects.all().explain()
    # print(Student.objects.all().explain())
    
    
# ================= field lookups ======================================
    # st=Student.objects.filter(name__exact="Anup")
    
    # st=Student.objects.filter(name__iexact="anup")
    
    # st=Student.objects.filter(name__contains="anup")
    
    # std=Student.objects.filter(name__icontains="a")
    
    # std=Student.objects.filter(id__in=[1,4,5])
    
    # std=Student.objects.filter(marks__in=[90])
    
    # std=Student.objects.filter(name__startswith="A")
    
    # std=Student.objects.filter(name__istartswith="m")
    
    # std=Student.objects.filter(name__iendswith="m")
    
    # std=Student.objects.filter(name__endswith="m")
    
    # std=Student.objects.filter(pass_date__range=("2020-04-1","2023-04-1"))

    # std=Student.objects.filter(pass_date__year__gt="2022")
    
    # std=Student.objects.filter(pass_date__year="2020")
    
    # std=Student.objects.filter(pass_date__month="05")

    # std=Student.objects.filter(pass_date__month="05")

    # std=Student.objects.filter(pass_date__month__gt="05")

    # std=Student.objects.filter(pass_date__month__gte="05")

    # std=Student.objects.filter(pass_date__day="04")

    # std=Student.objects.filter(pass_date__day__gt="04")


    # std=Student.objects.filter(pass_date__day__gte="04")

    # std=Student.objects.filter(pass_date__week="30")

    # std=Student.objects.filter(pass_date__week_day="5")

    # std=Student.objects.filter(pass_date__week_day="5")

    # std=Student.objects.filter(pass_date__second__gt="5") # this will support in datetime fields.add()
    
    std=Student.objects.filter(roll__isnull=False)




    
    




    







    
    
    print(std)
    return render(request,"index.html",{"std":std})