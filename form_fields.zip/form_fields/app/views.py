from django import forms
from django.shortcuts import render
from .forms import Student
# Create your views here.

def ShowForm(request):
    # fm=LoginForm(auto_id="some_%s",label_suffix=" ",initial={"name":"Anup Alone"})
    # fm.order_fields(field_order=["email","name"])
    # "some_%s" will set id=some_name or some_email according to the field.
     
    # fm=LoginForm(auto_id=True) 
    # if we set true then id=id_name and id=id_email
    
    # fm=LoginForm(auto_id=False) 
    # if we set true then id=name and id=email
    
    # fm=LoginForm(auto_id="anup") 
    # it will remove label and id attribute.
    
    #######################################################
    # Rendering manually
    if request.method == 'POST':
        fm=Student(request.POST)
        if fm.is_valid():
            print("Form validated")
            print("name :",request.POST["name"])
            print("agree :",request.POST["agree"])
            print("roll :",request.POST["roll"])
            print("price :",request.POST["price"])
            print("rate :",request.POST["rate"])
            print("email :",request.POST["email"])
            print("comment :",request.POST["comment"])
            print("website :",request.POST["website"])
            print("password :",request.POST["password"])
            print("description :",request.POST["description"])
            print("feedback :",request.POST["feedback"])
            print("notes :",request.POST["notes"])
            
            def clean_name(self):
                valname=self.cleaned_data["name"]
                if len(valname)<4:
                    raise forms.ValidationError("Enter more than 4 charecter")
                return valname
           
    else:
        fm=Student()
        
    return render(request,"app/index.html",{"form":fm})