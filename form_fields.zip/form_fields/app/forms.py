from django.forms import forms 
from django import forms

class Student(forms.Form):
    # name=forms.CharField(label_suffix="  ==>  (label_suffix)",initial="Anup (Initial value,but we give this initial value in view.py ie. in runtime then this will display.)",label=" Full Name (label)",required=False,disabled=False,help_text="This is for the Full name (help text)",max_length=20,min_length=3,error_messages={"required":"Please enter tour name !","max_length":"You cant go above the charecter limit  !","min_length":"You have to write above 3 charecters !"})
    
    # name=forms.CharField(max_length=20,min_length=3,error_messages={"required":"Please enter your name !","max_length":"You cant go above the charecter limit  !","min_length":"You have to write above 3 charecters !"},empty_value="Anup")
    
    name=forms.CharField()
    
    agree=forms.BooleanField(error_messages={"required":"Please enter your view !"},label="I agree",label_suffix=" =")
    
    roll=forms.IntegerField(max_value=100,min_value=5,error_messages={"required":"Please enter more than 5,till 100 "})
    
    price=forms.DecimalField(min_value=10,max_value=100,max_digits=4,decimal_places=2)
    
    rate=forms.FloatField(min_value=10,max_value=100)
    
    email=forms.EmailField(max_length=50,min_length=8)
    
    comment=forms.SlugField()
    
    website=forms.URLField(max_length=50,min_length=5)
    
    password=forms.CharField(widget=forms.PasswordInput,min_length=3,max_length=50)
    
    description=forms.CharField(widget=forms.Textarea)
    
    feedback=forms.CharField(min_length=5,max_length=1000,widget=forms.TextInput(attrs={"class":"someclass1 somecss","id":"uniqueid"}))

    notes=forms.CharField(widget=forms.TextInput(attrs={"rows":3,"column":4}))
    # key=forms.CharField(widget=forms.HiddenInput())
    