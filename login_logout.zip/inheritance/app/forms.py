from django import forms
from .models import User 

class Student_regi(forms.ModelForm):
    class Meta:
        model=User 
        fields=["student_name","email","password"]
        
        widgets={
            "student_name":forms.TextInput(attrs={"class":"form-control"}),
            
            "email":forms.EmailInput(attrs={"class":"form-control"}),
            
            "password":forms.PasswordInput(attrs={"class":"form-control"},render_value=True),
            # render value is to show password value in the form in update form.
            
            
            "std":forms.NumberInput(attrs={"class":"form-control"}),
        }
        

class Teacher_regi(forms.ModelForm):
    class Meta(Student_regi.Meta):
        model=User 
        fields=["teacher_name","email","password"]
        widgets={
            "teacher_name":forms.TextInput(attrs={"class":"form-control"}),
            
            "email":forms.EmailInput(attrs={"class":"form-control"}),
            
            "password":forms.PasswordInput(attrs={"class":"form-control"},render_value=True),
            # render value is to show password value in the form in update form.
         }