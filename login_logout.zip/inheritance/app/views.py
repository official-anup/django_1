from django.shortcuts import render
from .forms import Student_regi,Teacher_regi 
# Create your views her

def student(request):
    if request.method=="POST":
        fm=Student_regi(request.POST)
        if fm.is_valid():
            fm.save()
    
    else:
        fm=Student_regi()
    return render(request,"app/student.html",{"form":fm})

def teacher(request):
    if request.method=="POST":
        fm=Teacher_regi(request.POST)
        if fm.is_valid():
            fm.save()
    
    else:
        fm=Teacher_regi()
    return render(request,"app/teacher.html",{"form":fm})