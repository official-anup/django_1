
from django.contrib import admin
from django.urls import path
from app import views
# from app.forms import LoginForm
from django.contrib.auth.views import LoginView
from django.contrib.auth import views as auth_view 

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('signup1/', views.Regi),
    path('signup2/', views.signup,name="signup"),
    path('', views.loginform,name="login"),
    # path('', auth_view.LoginView.as_view(template_name="login.html",authentication_form=LoginForm),name="login"),
    
    path('dashboard/', views.dashboard,name="dashboard"),
    path('logout/', views.logoutview,name="logout"),
   
   
    
    
    
    
    
    
    
    
    
]
