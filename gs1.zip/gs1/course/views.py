from django.shortcuts import render


# Create your views here.
def django(request):
    # return  HttpResponse("hello django")
    return render(request,"app2/index3.html")