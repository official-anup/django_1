from django.http import HttpResponse
from django.shortcuts import render
 
# Create your views here.

def hello(request):
    # return  HttpResponse("hello django")
    return render(request,"core/index1.html")

def hello2(request):
    # return  HttpResponse("hello django")
    return render(request,"core/index2.html")