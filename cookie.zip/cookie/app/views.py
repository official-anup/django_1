from datetime import datetime, timedelta
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def setcookie(request):
    response=render(request,"set.html")
    # response.set_cookie("name","anup",max_age=60*60*24*10)
    response.set_cookie("name","anup",expires=datetime.utcnow()+timedelta(days=2))
    return response

def getcookie(request):
    # name=request.COOKIES["name"]
    name=request.COOKIES.get("nm","nahi mila")
    # HttpResponse.set_signed_cookie("name","anup",salt="max_age=None,expires=None,path="/",domain=None,secure=False,httponly=False,samesite=None)
    return render(request,"get.html",{"name":name})

def delcookie(request):
    response= render(request,"del.html")
    response.delete_cookie("name")
    return response


################# signed cookies ##############################

def setsignedcookie(request):
    response=render(request,"set.html")
    response.set_signed_cookiet("name","anup",salt="nm",expires=datetime.utcnow()+timedelta(days=2))
    return response

def getsignedcookie(request):
    name=request.set_signed_cookie("name",salt="nm")
    return render(request,"get.html",{"name":name})

def delsignedcookie(request):
    response= render(request,"del.html")
    response.delete_cookie("name")
    return response