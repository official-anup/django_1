
from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('set/', views.setcookie),
    path('get/', views.getcookie),
    path('del/', views.delcookie),
    path('getS/', views.getsignedcookie),
    path('setS/', views.setsignedcookie),
    path('delS/', views.delsignedcookie),
    
    
    
    
]
