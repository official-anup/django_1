from django.shortcuts import render

# Create your views here.
def home(request,check):
    return render(request,"home.html",{"check":check})

def show_data(request,id):
    if id==1:
        std={"id":id,"name":"Anup"}
    
    if id==2:
        std={"id":id,"name":"Monti"}
    
    if id==3:
        std={"id":id,"name":"Minti"}
    return render(request,"index.html",{"std":std})

def show_subdata(request,id,my_id):
    if id==1 and my_id==5:
        std={"id":id,"name":"Anup","info":"subdetails"}
    
    if id==2 and my_id==6:
        std={"id":id,"name":"Monti","info":"subdetails"}
    
    if id==3 and my_id==7:
        std={"id":id,"name":"Minti","info":"subdetails"}
    return render(request,"index.html",{"std":std})