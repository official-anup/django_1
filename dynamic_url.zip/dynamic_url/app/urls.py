
from django.contrib import admin
from django.urls import path
from app import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('<int:id>', views.show_data,name="details"),
    path('<int:id>/<int:my_id>', views.show_subdata,name="subdetails"),
    
    
    
]
