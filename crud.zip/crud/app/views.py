from django import forms
from django.shortcuts import render
from .forms import Student
from .models import Registration
# Create your views here.

# UPDATE WITH THE INSTANCE 
def ShowForm(request):
        if request.method=="POST":
            pi=Registration.objects.get(pk=3)
            fm=Student(request.POST,instance=pi)
            if fm.is_valid():
                fm.save()

"""
def ShowForm(request):
            if request.method=="POST":
                fm=Student(request.POST)
                if fm.is_valid():
                    name=request.POST["name"]
                    
                    email=request.POST["email"]
                    
                    password=request.POST["password"]
                    # password=fm.cleaned_data["password"]
                    
                    ########## to create record ############### 
                    obj=Registration(name=name,email=email,password=password)
                    obj.save()
                    
                    ########## to delete record ############### 
                    # delete_record=Registration(id=2)
                    # delete_record.delete()
                    
                    ########## to update record ############### 
                    # obj=Registration(id=1,name=name,email=email,password=password)
                    # obj.save()
                    
            else:
                fm=Student()
                
            return render(request,"app/index.html",{"form":fm})
"""