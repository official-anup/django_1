from django.shortcuts import render,HttpResponseRedirect
from .forms import Student
# Create your views here.

def ShowForm(request):
    if request.method=="POST":
        fm=Student(request.POST)
        # print(fm)
        # if fm.is_valid():
        #     print(fm.cleaned_data)
        #     print("yes post request se aya h")
        
        
        # if fm.is_valid():
        #     print(fm.cleaned_data["name"])
        #     print(fm.cleaned_data["email"])
        
        if fm.is_valid():
            name=request.POST["name"]
            email=request.POST["email"]
            print(name)
            print(email)
            
            # obj=Student(roll=roll,name=name,email=email,address=address,mob=mob)
            # obj.save()
            
            # return HttpResponseRedirect("app/index2.html") #for this we have to add another url

            # return render(request,"app/index2.html",{"nm":name})
            
    else:
        fm=Student()
        print("yes get request se aya h")
                
    return render(request,"app/index.html",{"form":fm})