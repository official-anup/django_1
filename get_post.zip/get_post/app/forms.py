from django.forms import forms 
from django import forms

class Student(forms.Form):
    # name=forms.CharField(label_suffix="  ==>  (label_suffix)",initial="Anup (Initial value,but we give this initial value in view.py ie. in runtime then this will display.)",label=" Full Name (label)",required=False,disabled=False,help_text="This is for the Full name (help text)")
    
    name=forms.CharField()
    email=forms.EmailField()

    