
from django.shortcuts import render,HttpResponse
"""
################# import test cookie ###########################
def settestcookie(request):
    request.session.set_test_cookie()
    return render(request,"set.html")

def checktestcookie(request):
    request.session.test_cookie_worked()
    return render(request,"check.html")

def deltestcookie(request):
    request.session.delete_test_cookie()
    return render(request,"del.html")


"""

############### other functions ##############################
# """
def setsesison(request):
    request.session["name"]="Anup"
    # request.session["lname"]="Alone"
    
    # set_expiry=request.session.set_expiry(6000)
    # return render(request,"set.html",{"set_expiry":set_expiry})
    return render(request,"set.html")
    


# def getsession(request):
#     # name= request.session['name']
    
#     name= request.session.get('name',"nahi mila")
    
#     key=request.session.keys()
#     item=request.session.items()
#     age=request.session.setdefault("age",27)
    
#     expire_age=request.session.get_expiry_age()
#     expire_date=request.session.get_expiry_date()
#     age1=request.session.get_session_cookie_age()
#     get_expire_at_browser_close=request.session.get_expire_at_browser_close()
    
#     return render(request,"get.html",{"name":name,"key":key,"item":item,"age":age,"expire_date":expire_date,"expire_age":expire_age,"age1":age1,"get_expire_at_browser_close":get_expire_at_browser_close})


def getsession(request):
    if "name" in request.session:
        name=request.session["name"]
        request.session.modified=True # if we refresh the page before 20 seconds as wee mentioned in the setting,then it will not delete the session.
        return render(request,"get.html",{"name":name})
    
    else:
        return HttpResponse("<h1>Your session is expired !</h1>")
        
# def delsession(request):
#     if "name" in request.session:
#         del request.session['name']
#     return render(request,"del.html")
    
def delsession(request):
    request.session.flush()
    request.session.clear_expired() #to delete the expired session from database.
    return render(request,"del.html")

# """

