from django.shortcuts import render
from django.views.decorators.cache import cache_page

from django.core.cache import cache

# Create your views here.

#86
"""
def home(request):
    # see setting file at the last
    return render(request,"index.html")
    
""" 

# 87 
# @cache_page(20)
# def home(request):
#     ch=cache.get("movie","has_expired")
#     if ch=="has_expired":
#         cache.set("movie","iron man",30)
#         ch=cache.get("movie")
#     return render(request,"index.html",{"ch":ch})


# def home(request):
#     fm=cache.get_or_set("fees",200,30,version=2)
#     return render(request,"index.html",{"fm":fm})
    

# def home(request):
#     data={"name":"anup","age":27}
#     cache.set_many(data,30)
#     fm=cache.get_many(data)
#     return render(request,"index.html",{"fm":fm})


# def home(request):
#     # cache.delete("age") # this will delete the age from the database
#     # cache.delete("fees",version=2)
#     return render(request,"index.html")
    
# def home(request):
#     # cache.set("roll",11122,3000) # roll is set for the 3000 seconds
#     # fm=cache.get("roll")
#     fm=cache.decr("roll",delta=1) #delta for decreases or increases by counter that we specified.
#     return render(request,"index.html",{"fm":fm})
    
def home(request):
    cache.clear()
    return render(request,"index.html")

def contact(request):
    return render(request,"contact.html")