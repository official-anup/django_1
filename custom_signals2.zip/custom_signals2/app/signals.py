from django.dispatch import Signal,receiver
from django import dispatch

# code_task_done = dispatch.Signal(providing_args=["code_id"])
#creating signals
notification=Signal(["request","user"]) 


#receiver function
@receiver(notification)
def show_notification(sender,**kwargs):
    print("sender",sender)
    print("kwargs",kwargs)
    print("notification",notification)

    
