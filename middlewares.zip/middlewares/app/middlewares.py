def my_middleware(get_response):
    print("one time initialization.")# This will execute after the runserver
    
    def my_fun(request):# This will execute after the refressing or running the view
        print("This is before view.")
        
        response=get_response(request) # It will fetch the code or the execution of the view
        print("This is after view.")
        return response
    return my_fun

# class Mymiddleware:
#     def __init__(self,get_response):
#         self.get_response=get_response
#         #one time configuration and initialization.
#         print("This is initialization for my-middleware")
        
#     def __Call__(self,request):
#             #code to be executed for each request before the view(and later the middleware) are called. 
#             print("This is before my-middleware view")
#             response=self.get_response(request)
#             #code to be executed for each request/ response after the view is called. 
#             print("This is after my-middleware view")
            
#             return response


# #It will exeucte from mummy -> father ->brother
# class Brothermiddleware:
#     def __init__(self,get_response):
#         self.get_response=get_response
#         #one time configuration and initialization.
#         print("This is initialization for brother-middleware")
        
#     def __Call__(self,request):
#         #code to be executed for each request before the view(and later the middleware) are called. 
#         print("This is after brother-middleware view")
        
#         response=self.get_response(request)
#         #code to be executed for each request/ response after the view is called. 
#         print("This is after brother-middleware view")
        
#         return response
    
# class Fathermiddleware:
#     def __init__(self,get_response):
#         self.get_response=get_response
#         #one time configuration and initialization.
#         print("This is initialization for father-middleware")
        
#     def __Call__(self,request):
#         #code to be executed for each request before the view(and later the middleware) are called. 
#         print("This is after father-middleware view")
        
#         response=self.get_response(request)
#         #code to be executed for each request/ response after the view is called. 
#         print("This is after father-middleware view")
        
#         return response

# class Mothermiddleware:
#     def __init__(self,get_response):
#         self.get_response=get_response
#         #one time configuration and initialization.
#         print("This is initialization for mother-middleware")
        
#     def __Call__(self,request):
#         #code to be executed for each request before the view(and later the middleware) are called. 
#         print("This is after mother-middleware view")
        
#         response=self.get_response(request)
#         #code to be executed for each request/ response after the view is called. 
#         print("This is after mother-middleware view")
        
#         return response
    