from datetime import date
from django.db import connection
from django.shortcuts import render
from .models import Student,Teacher
from django.db.models import  Q
from django.db.models import Sum, Avg, Max, Min,Count
# Create your views here.
def show_data(request):
    # std=Student.objects.all()
    
    # std=Student.objects.filter(f_name__startswith="a")
    
    # std=Student.objects.filter(l_name__startswith="alone") | Student.objects.filter(l_name__startswith="khan")
    
    # std=Student.objects.filter(age__gt=30)
    # std=Student.objects.filter(age__gte=30) #greater than equal to
    # std=Student.objects.filter(age__lt=30)
    # std=Student.objects.filter(age__lte=30)
    
    # std=Student.objects.filter(~Q(age__lte=30)) # ~Q means not lower than 30
    # std=Student.objects.filter(~Q(age=24))
    
    # std=Student.objects.filter(Q(f_name__startswith="a") | Q(l_name__startswith="a"))
    
    # std=Student.objects.filter(f_name__startswith="a") | Student.objects.filter(l_name__startswith="a")
    
    
    # std=Student.objects.filter(age=27) & Student.objects.filter(f_name="anup")
    
    # std=Student.objects.all().values_list("f_name").union(Teacher.objects.all().values_list("f_name"))
    
    # select * from student where not age=27
    # std=Student.objects.exclude(age=27)
    # std=Student.objects.exclude(f_name__startswith="jay")
    
    # std=Student.objects.filter(age=24).only("f_name")
    # std=Student.objects.raw("select * from app_Student")
    
    # std=Student.objects.filter(Q(date__day=15) & Q(date__month=date.today().month))
    
    # std = Student.objects.order_by('f_name')
    # std = Student.objects.order_by('l_name')
    # std = Student.objects.order_by('age')
    
    
    # std = Student.objects.filter(f_name="anup",l_name="kumar")
    
    ###############  icontains="a" ######################
    # std = Student.objects.filter(f_name__icontains="a")
    
    
    ################# bypass orm ###################
    # cursor=connection.cursor()
    # cursor.execute("select * from app_Student")
    # r=cursor.fetchall()
    
    #################### first and last  ########################
    # std = Student.objects.first()
    
    ################ aggregations ######################
    # std = Student.objects.all().aggregate(Sum('age'))
    # std = Student.objects.all().aggregate(Avg('age'))
    # std = Student.objects.all().aggregate(Min('age'))
    # std = Student.objects.all().aggregate(Sum('age'))
    
################### Fetch specific columns ###########################
    
        """ 
        SELECT name, age
        FROM Person;
        """
        # std=Student.objects.only('f_name', 'age')
        # return render(request,"app/index.html",{"std":std})
################## Limit ############################
    #    """ 
    #     SELECT *
    #     FROM Person
    #     LIMIT 10;
    #     Django:

    #    """
        # std=Student.objects.all()[:10]
        # return render(request,"app/index.html",{"std":std}) 
    
###################limit and offset  ###############################

        # SELECT *
        # FROM Person
        # OFFSET 5
        # LIMIT 5;

        # std=Student.objects.all()[5:10]
        # return render(request,"app/index.html",{"std":std}) 

################# where #####################################
# SELECT *
# FROM Person
# WHERE id = 1;
        
        # std=Student.objects.all()[5:10]
        # return render(request,"app/index.html",{"std":std}) 
        
#################### range ##########################
# SELECT *
# FROM Person 
# WHERE age BETWEEN 10 AND 20;


        # std=Student.filter(age__range=(10, 20))
        # return render(request,"app/index.html",{"std":std}) 
        
###################### LIKE OPERATOR ##############################
# WHERE name like '%A%';
# WHERE name like binary '%A%';
# WHERE name like 'A%';
# WHERE name like binary 'A%';
# WHERE name like '%A';
# WHERE name like binary '%A';


        # std=Student.objects.filter(f_name__icontains='A')
        # std=Student.objects.filter(f_name__contains='A')
        # std=Student.objects.filter(f_name__istartswith='A')
        # std=Student.objects.filter(f_name__startswith='A')
        # std=Student.objects.filter(f_name__iendswith='A')
        # std=Student.objects.filter(f_name__endswith='A')
        # return render(request,"app/index.html",{"std":std})
    
################## IN operator ######################################
# WHERE id in (1, 2);

        # std=Student.objects.filter(id__in=[1, 2])
        # return render(request,"app/index.html",{"std":std})
        
#################### And ,OR,Not#############################
# WHERE gender='male' AND age > 25;

        # std=Student.objects.filter(gender='male', age__gt=25)
        # return render(request,"app/index.html",{"std":std})


# WHERE gender='male' OR age > 25;

       
        # std=Student.objects.filter(Q(gender='male') | Q(age__gt=25))
        
        
# WHERE NOT gender='male';
        # std=Student.objects.exclude(gender='male')
        
#################### NULL values #############################
# WHERE age is NULL;
# WHERE age is NOT NULL;


        # std=Student.objects.filter(age__isnull=True)
        # std=Student.objects.filter(age__isnull=False)

        # # Alternate approach
        # std=Student.objects.filter(age=None)
        # std=Student.objects.exclude(age=None)

#################### ORDER BY  #############################
# SELECT *
# FROM Person
# order by age;

        # std=Student.objects.order_by('age')

#################### DESCENDING ORDER #############################
# SELECT *
# FROM Person
# ORDER BY age DESC;

        # std=Student.objects.order_by('-age')

#################### INSER INTO #############################
# INSERT INTO Person
# VALUES ('Jack', '23', 'male');

        # std=Student.objects.create(name='jack', age=23, gender="male")
        
    
#################### Update single row #############################
# UPDATE Person
# SET age = 20
# WHERE id = 1;

        # std = Student.objects.get(id=1)
        # std.age = 20
        # std.save()

#################### update multiple row #############################

# UPDATE Person
# SET age = age * 1.5;


# from django.db.models import F

# std=Student.objects.update(age=F('age')*1.5)

#################### DELETE ALL ROWS #############################

# DELETE FROM Person;

        # std=Student.objects.all().delete()
        
#################### DELETE SPECIFIC ROW #############################
# DELETE FROM Person
# WHERE age < 10;

# std=Student.objects.filter(age__lt=10).delete()

#################### count  #############################
# SELECT COUNT(*)
# FROM Person;

# std=Student.objects.count()


#################### GROUP BY  #############################
# SELECT gender, COUNT(*) as count
# FROM Person
# GROUP BY gender;

from django.db.models import Count
# std=Student.objects.values('gender').annotate(count=Count('gender'))


#################### having  #############################
# 1)Count of Person by gender if number of person is greater than 1

# SELECT gender, COUNT('gender') as count
# FROM Person
# GROUP BY gender
# HAVING count > 1;


# std=Student.objects.annotate(count=Count('gender')).values('gender', 'count').filter(count__gt=1)

#################### JOINS  #############################


#################### count  #############################


#################### count  #############################

 