from django.contrib import admin
from .models import Student,Teacher
# Register your models here.
# admin.site.register(Student)

@admin.register(Student)
class StudentRegistration(admin.ModelAdmin):
    list_display=("id","f_name","l_name","age","fees")
    
@admin.register(Teacher)
class TeacherRegistration(admin.ModelAdmin):
    list_display=("id","f_name","l_name","age")