from django.db import models

# Create your models here.
class Student(models.Model):
    f_name=models.CharField(max_length=50)
    l_name=models.CharField(max_length=50)
    age=models.IntegerField()
    fees=models.FloatField()
    # dob=models.DateField()
    
    
class Teacher(models.Model):
    f_name=models.CharField(max_length=50)
    l_name=models.CharField(max_length=50)
    age=models.IntegerField()
   
    