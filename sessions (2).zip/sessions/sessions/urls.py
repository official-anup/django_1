
from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
################# import test cookie #########
    # path('set/', views.settestcookie),
    # path('check/', views.checktestcookie),
    # path('del/', views.deltestcookie),
    

    
    
############### other functions #####################
    path('set/', views.setsesison),
    path('get/', views.getsession),
    path('del/', views.delsession),
   
]
