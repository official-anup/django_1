from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


# This is to use our forms with out specified fields
class SignUpForm(UserCreationForm):
    password2=forms.CharField(label="Confirm password (again)",widget=forms.PasswordInput)
    class Meta:
        model=User
        fields=["username","first_name","last_name","email"]
        labels={
            "email":"Email"
        }