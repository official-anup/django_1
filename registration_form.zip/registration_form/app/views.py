from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from .forms import SignUpForm
from django.contrib import messages

# Create your views here.

# This is to use default forms with default fields
def Regi(request):
    if request.method=="POST":
       fm=UserCreationForm(request.POST)
       if fm.is_valid():
           messages.success(request,"Account created successfully.")
           fm.save()
           

           
    
    else:
       fm=UserCreationForm()
    return render(request,"registration.html",{"form":fm})

# This is to use our forms with out specified fields
def signup(request):
    if request.method=="POST":
       fm=SignUpForm(request.POST)
    #    fm.field_order(field_order=["email","username"])
       if fm.is_valid():
           messages.success(request,"Account created successfully.")
           
           fm.save()
    
    else:
       fm=SignUpForm()
    return render(request,"registration.html",{"form":fm})