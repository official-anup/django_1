from django.shortcuts import render
from .models import Student
# Create your views here.

def home(request):
    # student_data=Student.std.all()
    # student_data=Student.objects.all()
    student_data=Student.std.get_roll_range(2,3)
    
    
    return render(request,"home.html",{"student_data":student_data})
