from django.db.models import Manager
from django.db.models.query import QuerySet

"""

class CustomManager(Manager):
    def get_queryset(self):
        return super().get_queryset().order_by("name") # when query will fire then the data will be sorted on the basis of the name
"""

##################################################### 
# ADD EXTRA MANAGER METHODS
class CustomManager(Manager):
    def get_roll_range(self,r1,r2):
        return super().get_queryset().filter(roll__range=(r1,r2))