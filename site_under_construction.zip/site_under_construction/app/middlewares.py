from django.shortcuts import HttpResponse

def my_middleware(get_response):
    print("one time initialization.")# This will execute after the runserver
    
    
    def my_fun(request):# This will execute after the refressing or running the view
        print("This is before view.")
        
        # or we can render any template that shows the site is uner construction
        response=HttpResponse("<h1>This site is under construction.</h1>")
        print("This is after view.")
        return response
    return my_fun
