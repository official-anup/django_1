from django.shortcuts import render,HttpResponse

# Create your views here.
def home(request):
    print("I am view")
    return HttpResponse("<h1>This is home page</h1>")