from django.contrib import admin
# from .models import Student,Teacher,Contractor
# from .models import ExamCenter,Student2
# Register your models here.


# This is for the abstract base class
"""
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display=["id","name","age","fees"]

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display=["id","name","age","salary"]
    
@admin.register(Contractor)
class ContractorAdmin(admin.ModelAdmin):
    list_display=["id","name","age","payment","date"]

"""

# This  is for the multi-table inheritance
"""
@admin.register(ExamCenter)
class ExamCenterAdmin(admin.ModelAdmin):
    list_display=["id","c_name","c_city"]
    
@admin.register(Student2)
class StudentAdmin(admin.ModelAdmin):
    list_display=["id","s_name","s_roll","c_name","c_city"]
"""
