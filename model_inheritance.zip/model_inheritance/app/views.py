from django.shortcuts import render
# from .models import Student,Teacher,Contractor
# Create your views here.


# This is for the abstract base class
"""
def abstract_base_class(request):
    student_data=Student.objects.all()
    teacher_data=Teacher.objects.all()
    Contractor_data=Contractor.objects.all()
    
    return render(request,"home.html",{"student_data":student_data,"teacher_data":teacher_data,"Contractor_data":Contractor_data})

"""

