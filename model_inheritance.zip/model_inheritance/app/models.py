from django.db import models

# Create your models here.

# This is for the abstract base class 
"""
class CommonInfo(models.Model):
    name=models.CharField(max_length=70)
    age=models.IntegerField()
    date=models.DateField()
    
    class Meta:
        abstract=True
        
class Student(CommonInfo):
    fees=models.FloatField()
    date=None #It will not take date field of the abstract class.
    
class Teacher(CommonInfo):
    salary=models.FloatField()
    
    
class Contractor(CommonInfo):
    payment=models.FloatField()
    date=models.DateTimeField()
    
"""


#This is for the multi table inheritance
"""
class ExamCenter(models.Model):
    c_name=models.CharField(max_length=70)
    c_city=models.CharField(max_length=70)
    
class Student2(ExamCenter):
    s_name=models.CharField(max_length=70)
    s_roll=models.IntegerField()
    # In the database it will create Student2 table with ExamCenter_id,s_name and s_roll
    
""" 

# This is for the proxy model.
class ExamCenter2(models.Model):
    c_name=models.CharField(max_length=70)
    c_city=models.CharField(max_length=70)

class MyExamCenter(ExamCenter2):
    class Meta:
        proxy=True
        ordering=["c_city"]
        # Jo v data base class me dalenge wo wo child class me ayega and jo v data child me dalenge wo base class me dikhega in admin panel.But internally ek hi database bna hota h,see in sqlite.
    
