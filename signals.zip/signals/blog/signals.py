from django.contrib.auth.signals import user_logged_in,user_logged_out,user_login_failed
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import pre_delete,pre_init,pre_save,post_delete,post_init,post_save,pre_migrate,post_migrate

from django.core.signals import got_request_exception,request_finished,request_started
from django.db.backends.signals import connection_created

#It is working with the receiver decorator but not with the connect method as we defined below the function
@receiver(user_logged_in,sender=User)
def login_signals(sender,request,user,**kwargs):
    print("Run login_signals-----------------------")
    print("Sender",sender)
    print("Request",request)
    print("User",user)
    print("User-Password",user.password)
    print("User-Email",user.email)
    print(f"kwargs : {kwargs}")
    
    # user_logged_in(login_signals,sender=User)


@receiver(user_logged_out,sender=User)
def logout_signals(sender,request,user,**kwargs):
    print("Run logout_signals:---------------------")
    print("Sender",sender)
    print("Request",request)
    print("User",user)
    print("User-Password",user.password)
    print("User-Email",user.email)
    print(f"kwargs : {kwargs}")
    
@receiver(user_login_failed)
def login_failed_signals(sender,request,credentials,**kwargs):
    print("Run login_failed_signals:----------------")
    print("Sender",sender)
    print("Request",request)
    print("credential",credentials)
    print(f"kwargs : {kwargs}")
    
    
#This will run when we login into the admin panel,then first pre-save runs and then user_logged_in
@receiver(pre_save,sender=User)
def pre_save_signals(sender,instance,**kwargs):
    print("Run pre_save_signals:--------------------")
    print("Sender",sender)
    print(f"kwargs : {kwargs}")
    print(f"instance : {instance}")
    
@receiver(post_save,sender=User)
def post_save_signals(sender,instance,created,**kwargs):
    if created:     
            print("Run post_save_signals:--------------------")
            print("New record...")
            print("Sender",sender)
            print(f"kwargs : {kwargs}")
            print(f"instance : {instance}")
            print("created",created)
            
    else:
        print("Run post_save_signals:--------------------")
        print("Update...")
        print("Sender",sender)
        print(f"kwargs : {kwargs}")
        print(f"instance : {instance}")
        print("created :",created)
        
@receiver(pre_delete,sender=User)
def pre_delete_signals(sender,instance,using,**kwargs):     
            print("Run pre_delete_signals:--------------------")
            print("using :",using)
            print("Sender",sender)
            print(f"kwargs : {kwargs}")
            print(f"instance : {instance}")
            

@receiver(post_delete,sender=User)
def post_delete_signals(sender,instance,using,**kwargs):     
            print("Run post_delete_signals:--------------------")
            print("using :",using)
            print("Sender",sender)
            print(f"kwargs : {kwargs}")
            print(f"instance : {instance}")
            
@receiver(pre_init,sender=User)
def pre_init_signals(sender,*args,**kwargs):  
            print("------------------------------------")
       
            print("Run pre_init_signals:-------------")
            print("Args :",args)
            print(f"kwargs : {kwargs}")
            print("Sender",sender)
           
            

@receiver(post_init,sender=User)
def post_init_signals(sender,*args,**kwargs): 
            print("------------------------------------")
        
            print("Run post_init_signals:-----------")
            print("Args :",args)
            print(f"kwargs : {kwargs}")
            print("Sender",sender)
            print("------------------------------------")
            
           
@receiver(request_started)
def request_started_signals(sender,environ,**kwargs): 
            print("-----------------------------")
            print("Run request_started_signals:-----------")
            print("Environ :",environ)
            print("Sender",sender)
            print("kwargs",kwargs)
            print("--------------------------------")
                     
@receiver(request_finished)
def request_finished_signals(sender,**kwargs): 
            print("-----------------------------")
            print("Run request_finished_signals:--------")
            print("Sender",sender)
            print("kwargs",kwargs)
            print("--------------------------------")
            
@receiver(got_request_exception)
def got_request_exception_signals(sender,request,**kwargs): 
            print("-----------------------------")
            print("Run got_request_exception_signals:--------")
            print("Sender",sender)
            print("Request",request)
            print("kwargs",kwargs)
            print("--------------------------------")
            
@receiver(pre_migrate)
def pre_migrate_signals(sender,app_config,verbosity,interactive,using,plan,apps,**kwargs): 
            print("-----------------------------")
            print("Run pre_migrate_signals:--------")
            print("Sender",sender)
            print("app_config :",app_config)
            print("verbosity :",verbosity)
            print("interactive :",interactive)
            print("using :",using)
            print("plan :",plan)
            print("apps :",apps)
            print("kwargs :",kwargs)

@receiver(post_migrate)
def post_migrate_signals(sender,app_config,verbosity,interactive,using,plan,apps,**kwargs): 
            print("-----------------------------")
            print("Run post_migrate_signals:--------")
            print("Sender",sender)
            print("app_config :",app_config)
            print("verbosity :",verbosity)
            print("interactive :",interactive)
            print("using :",using)
            print("plan :",plan)
            print("apps :",apps)
            print("kwargs :",kwargs)
            print("--------------------------------")
            
@receiver(connection_created)
def connection_created_signals(sender,connection,**kwargs): 
            print("-----------------------------")
            print("Run connection_created_signals:--------")
            print("Sender",sender)
            print("connection",connection)
            print("kwargs",kwargs)
            print("--------------------------------")
            