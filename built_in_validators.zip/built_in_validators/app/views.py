from django import forms
from django.shortcuts import render
from .forms import Student
# Create your views here.

def ShowForm(request):
            if request.method=="POST":
                fm=Student(request.POST)
                if fm.is_valid():
                    print("Form validated")
                    print("name :",request.POST["name"])
            
            else:
                fm=Student()
                
            return render(request,"app/index.html",{"form":fm})
