from django.forms import forms 
from django import forms
from django.core import validators 


# Built in validators
"""
class Student(forms.Form):
    name=forms.CharField(validators=[validators.MaxLengthValidator(15)])
    
    emial=forms.EmailField()
    
"""

# custom validators 

def starts_with_s(input):
    if input[0]!="s".casefold():
        raise forms.ValidationError("Name should starts with S.")

class Student(forms.Form):
    name=forms.CharField(validators=[starts_with_s])
    email=forms.EmailField()

####################################################

# validation for one field
#############################################
"""
class Student(forms.Form):
    name=forms.CharField()
    
    def clean_name(self):
                valname=self.cleaned_data["name"]
                if len(valname)<4:
                    raise forms.ValidationError("Enter more than 4 charecter")
                return valname

"""
# validation for the whole form
#############################################
"""

class Student(forms.Form):
    name=forms.CharField()
    email=forms.EmailField()
    
    def clean(self):
        clean_data=super().clean()
        
        valname=self.cleaned_data["name"]
        valemail=self.cleaned_data["email"]
        
        # If both the feilds have errors then only first field error will shown.
        
        if len(valname)<4:
            raise forms.ValidationError("Name should be more or equal to 4 !")
        
        
        if len(valemail)<8:
            raise forms.ValidationError("Email should be more than 8 charectors.")

"""
